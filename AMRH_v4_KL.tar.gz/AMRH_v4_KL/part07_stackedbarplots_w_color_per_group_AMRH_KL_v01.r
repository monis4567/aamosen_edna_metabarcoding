#!/usr/bin/env Rscript
# -*- coding: utf-8 -*-

#

# For AMRH_KL
#___________________________

#
#################################################################################
#
# Code developed for analysis of metabarcode NGS data
# obtained with NGS
#
# code prepared by Johan M Sørensen, Anne Marie Rubæk Holm and Steen Wilhelm Knudsen
# in Jan-2020 at the Zoological Museum of Copenhagen

# With the aim of producing stacked bar plots as
# what is presented in these studies:
# Fig. 4 , in Thomsen et al. 2016. PlosOne.   ( https://doi.org/10.1371/journal.pone.0165252)
# Fig. 2 in Li et al., 2019. (DOI: 10.1111/1365-2664.13352.)
# Fig. 4. in Guenther et al. 2018. Sci Reports. (2018) 8:14822 (DOI:10.1038/s41598-018-32917-x.)

# This code has been tested in this version of R:
# > R.Version()
#$platform
#[1] "x86_64-pc-linux-gnu"
#
#$arch
#[1] "x86_64"
#
#$os
#[1] "linux-gnu"
#
#$system
#[1] "x86_64, linux-gnu"
#
#$status
#[1] ""
#
#$major
#[1] "3"
#
#$minor
#[1] "5.2"
#
#$year
#[1] "2018"
#
#$month
#[1] "12"
#
#$day
#[1] "20"
#
#$`svn rev`
#[1] "75870"
#
#$language
#[1] "R"
#
#$version.string
#[1] "R version 3.5.2 (2018-12-20)"
#
#$nickname
#[1] "Eggshell Igloo"


#https://www.r-graph-gallery.com/all-graphs.html




#my_wd <- "/home/johan/Desktop/Metabarcoding/part04-06/blastresults_JMS_MFE/filtreret_WIO"
#set working directory
#setwd(my_wd)
# replace my library path to your own library path
lib_path01 <- "/groups/hologenomics/phq599/data/R_packages_for_Rv3_6"
Sys.setenv(R_LIBS_USER="lib_path01")
.libPaths("lib_path01")
# change the path to where the packages should be installed from # see this website: https://stackoverflow.com/questions/15170399/change-r-default-library-path-using-libpaths-in-rprofile-site-fails-to-work
.libPaths( c( lib_path01 , .libPaths() ) )
.libPaths()


# #my_wd <- "/home/hal9000/metabarcode_example/JMS_FL/1-demultiplexed"
#my_wd <- "/home/hal9000/metabarcode_example/AMRH_KL_v2"
 # #set working directory
# setwd(my_wd)
# #prints current working directory to screen
# getwd()
# define the input file names
# first read in the renamed 'DADA2_nochim.table'
#that has been renamed to : 'part03_DADA2_nochim.table.JMS_FL.txt'
#read unfiltered nochim.table (no local species list filtration)
# define the input file names
# first read in the renamed 'DADA2_nochim.table' 
#that has been renamed to : 'part03_DADA2_nochim.table.JMS_FL.txt'
libnm <-"AMRH_KL"
inp_fn1 <- paste("part03_DADA2_nochim.table.",libnm,".txt",sep="")
#inp_fn2 <- "part06_my_classified_otus_JMSFL.01.unfilt_BLAST_results.txt"
inp_fn2 <- paste("part06_my_classified_otus_",libnm,".01.unfilt_BLAST_results.txt",sep="")
#inp_fn3 <- "part06_my_classified_otus_JMSFL.02.filt_BLAST_results.txt"
inp_fn3 <- paste("part06_my_classified_otus_",libnm,".02.filt_BLAST_results.txt",sep="")
# 
# inp_fn1 <- "../ufiltreret/part03_output_DADA2_nochim.table.JMS_MFE.txt"
# #red unfiltered otus  (no local species list filtration)
# inp_fn2 <- "../ufiltreret/part05_output_my_classified_otus_JMS_MFE.txt"
# #read filtered otus (with local species filtration)
# inp_fn3 <- "my_classified_otus.txt"

###Get packages
#install.packages("dplyr")
#install.packages("cowplot")

#install.packages("ggpubr")
if(!require(ggpubr)){
  install.packages("ggpubr")
  library(ggpubr)
}
library(ggpubr)

# if(!require(randomcoloR)){
#   install.packages("randomcoloR")
#   library(randomcoloR)
# }
#install.packages("ggplot2")
#install.packages("reshape2")
library(ggplot2)
library(reshape2)
library(ggpubr)
#library(randomcoloR)
#turn .table file with columns seperated by tab into table
# set 'fill=T' to TRUE to make sure that tables with irregular number of columns are read in as well
tbl_nochim01 <- read.table(file=inp_fn1,sep='\t',header=T, fill=T)

#read in the result from the taxonomyB_R code
# set 'fill=T' to TRUE to make sure that tables with irregular number of columns are read in as well
df_blast_unfilt_01 <- read.table(file=inp_fn2,sep='\t',header=T, stringsAsFactors = F, fill=T)
df_blast_filt_01 <- read.table(file=inp_fn3,sep='\t',header=T, stringsAsFactors = F, fill=T)
#you will need to read in the blast hit results with 'stringsAsFactors = F' to be able to
# replace the NA's later on

# see the first 4 header lines
#head(df_blast_unfilt_01,3)
#see what the columns are named
colnames(df_blast_unfilt_01)
#assign some of the columns to objects
blast_unfilt_seqID <- df_blast_unfilt_01$qseqid
blast_unfilt_class <- df_blast_unfilt_01[,11] #class
blast_unfilt_order <- df_blast_unfilt_01[,12] #order
blast_unfilt_fam <- df_blast_unfilt_01[,13] #family
blast_unfilt_genus <- df_blast_unfilt_01[,14] #genus
blast_unfilt_genus_species <- df_blast_unfilt_01[,15] #genus_species

blast_filt_seqID <- df_blast_filt_01$qseqid
blast_filt_class <- df_blast_filt_01[,11] #class
blast_filt_order <- df_blast_filt_01[,12] #order
blast_filt_fam <- df_blast_filt_01[,13] #family
blast_filt_genus <- df_blast_filt_01[,14] #genus
blast_filt_genus_species <- df_blast_filt_01[,15] #genus_species

#convert data frame from a "wide" format to a "long" format
df_nochim01_melt <- melt(tbl_nochim01, id = c("X"))

#change the column names
colnames(df_nochim01_melt)[1] <- c("SeqNo")
colnames(df_nochim01_melt)[2] <- c("smpl.loc")
colnames(df_nochim01_melt)[3] <- c("seq.rd.cnt")
head(df_nochim01_melt,4)
#match between data frames
df_nochim01_melt$blast_unfilt_class <- df_blast_unfilt_01[,11][match(df_nochim01_melt$SeqNo,df_blast_unfilt_01$qseqid)]
df_nochim01_melt$blast_unfilt_order <- df_blast_unfilt_01[,12][match(df_nochim01_melt$SeqNo,df_blast_unfilt_01$qseqid)]
df_nochim01_melt$blast_unfilt_fam <- df_blast_unfilt_01[,13][match(df_nochim01_melt$SeqNo,df_blast_unfilt_01$qseqid)]
df_nochim01_melt$blast_unfilt_genus <- df_blast_unfilt_01[,14][match(df_nochim01_melt$SeqNo,df_blast_unfilt_01$qseqid)]
df_nochim01_melt$blast_unfilt_genus_species <- df_blast_unfilt_01[,15][match(df_nochim01_melt$SeqNo,df_blast_unfilt_01$qseqid)]
#match between data frames
df_nochim01_melt$blast_filt_class <- df_blast_filt_01[,11][match(df_nochim01_melt$SeqNo,df_blast_filt_01$qseqid)]
df_nochim01_melt$blast_filt_order <- df_blast_filt_01[,12][match(df_nochim01_melt$SeqNo,df_blast_filt_01$qseqid)]
df_nochim01_melt$blast_filt_fam <- df_blast_filt_01[,13][match(df_nochim01_melt$SeqNo,df_blast_filt_01$qseqid)]
df_nochim01_melt$blast_filt_genus <- df_blast_filt_01[,14][match(df_nochim01_melt$SeqNo,df_blast_filt_01$qseqid)]
df_nochim01_melt$blast_filt_genus_species <- df_blast_filt_01[,15][match(df_nochim01_melt$SeqNo,df_blast_filt_01$qseqid)]

# Replace the NA's with 'none', you will have to read in your blast hit tables with 'stringsAsFactors = FALSE' flag
# to be allowed to make this change
df_nochim01_melt[is.na(df_nochim01_melt)] <- "none"
#make the counts a numeric value
df_nochim01_melt$seq.rd.cnt <- as.factor(df_nochim01_melt$seq.rd.cnt)
#make a column with full taxonomic path for unfiltered hits
df_nochim01_melt$blast_unfilt_class_ord_fam_gen_spc <-
  paste(df_nochim01_melt$blast_unfilt_class,
        df_nochim01_melt$blast_unfilt_order,
        df_nochim01_melt$blast_unfilt_fam,
        df_nochim01_melt$blast_unfilt_genus_species,
        sep="_")
#sort(unique(df_nochim01_melt$blast_unfilt_class_ord_fam_gen_spc))
#make a column with full taxonomic path for unfiltered hits
df_nochim01_melt$blast_filt_class_ord_fam_gen_spc <-
  paste(df_nochim01_melt$blast_filt_class,
        df_nochim01_melt$blast_filt_order,
        df_nochim01_melt$blast_filt_fam,
        df_nochim01_melt$blast_filt_genus_species,
        sep="_")
#see the different taxonomical hierachichal elements sorted alphabetically
#sort(unique(df_nochim01_melt$blast_filt_class_ord_fam_gen_spc))
#get count of unique elements for class for filtered BLAST hits
ll05 <-length(unique(df_nochim01_melt$blast_filt_class))
ll06 <-length(unique(df_nochim01_melt$blast_filt_fam))
#get count of unique elements for class for filtered BLAST hits
ll07 <-length(unique(df_nochim01_melt$blast_unfilt_class))
ll08 <-length(unique(df_nochim01_melt$blast_unfilt_fam))



#https://chartio.com/resources/tutorials/how-to-sort-a-data-frame-by-multiple-columns-in-r/
#reorder the data frame by class, then by fam then by genus and species
df_ncm02 <- df_nochim01_melt[
  with(df_nochim01_melt, order(blast_unfilt_class,
                               blast_unfilt_order,
                               blast_unfilt_fam,
                               blast_unfilt_genus_species)), ]

unique(df_ncm02$blast_unfilt_class)

#subset data frame if observations match or does not match
df_ncm03_unfilt_tspc <- df_ncm02[ which(df_ncm02$blast_unfilt_class=="Actinopteri" 
                                        | df_ncm02$blast_unfilt_class=="Mammalia"
                                        | df_ncm02$blast_unfilt_class=="Hyperoartia"
                                        | df_ncm02$blast_unfilt_class=="Chondrichthyes"), ]
#uncomment the next two lines if you want to check the unique elements in the new data frames
#unique(df_ncm02$blast_unfilt_class)
#unique(df_ncm03_unfilt_tspc$blast_unfilt_class)
df_ncm03_unfilt_not_tspc <- df_ncm02[ which(!df_ncm02$blast_unfilt_class=="Actinopteri"
                                            & !df_ncm02$blast_unfilt_class=="Mammalia"
                                            & !df_ncm02$blast_unfilt_class=="Hyperoartia"
                                            & !df_ncm02$blast_unfilt_class=="Chondrichthyes"), ]
#uncomment the next two lines if you want to check the unique elements in the new data frames
#unique(df_ncm02$blast_unfilt_class)
#unique(df_ncm03_unfilt_not_tspc$blast_unfilt_class)
df_ncm03_filt_tspc <- df_ncm02[ which(df_ncm02$blast_filt_class=="Actinopteri"
                                      | df_ncm02$blast_filt_class=="Mammalia"
                                      | df_ncm02$blast_filt_class=="Hyperoartia"
                                      | df_ncm02$blast_filt_class=="Chondrichthyes"), ]
#uncomment the next two lines if you want to check the unique elements in the new data frames
#unique(df_ncm02$blast_filt_class)
#unique(df_ncm03_filt_tspc$blast_filt_class)
df_ncm03_filt_not_tspc <- df_ncm02[ which(!df_ncm02$blast_filt_class=="Actinopteri" 
                                    & !df_ncm02$blast_filt_class=="Mammalia"
                                    & !df_ncm02$blast_filt_class=="Hyperoartia"
                                    & !df_ncm02$blast_filt_class=="Chondrichthyes"), ]
#uncomment the next two lines if you want to check the unique elements in the new data frames
#unique(df_ncm02$blast_filt_class)
#unique(df_ncm03_filt_not_tspc$blast_filt_class)
#get count of unique elements for class for unfiltered BLAST hits
ll05 <- length(unique(df_ncm03_unfilt_not_tspc$blast_unfilt_fam))
ll06 <- length(unique(df_ncm03_unfilt_tspc$blast_unfilt_fam))
#get count of unique elements for class for filtered BLAST hits
ll07 <- length(unique(df_ncm03_filt_not_tspc$blast_filt_fam))
ll08 <- length(unique(df_ncm03_filt_tspc$blast_filt_fam))


#https://stackoverflow.com/questions/15282580/how-to-generate-a-number-of-most-distinctive-colors-in-r
#library(randomcoloR)
#make a color palette for the unique elements
#pal01 <- distinctColorPalette(ll01)
#see the colors in a pie
#pie(rep(1,ll01), col=sample(pal01, ll01))
#assign color to coloumn in df matching the columns the colors were based on
#e01_df$cg01 <- c(pal01)[e01_df$a12]
#install.packages("viridis")
library(viridis)
#make a colour range on the family matches in unfiltered BLAST elements
pal05<-viridis_pal(option = "A")(ll05) # not Actinop unfiltered
pal06<-viridis_pal(option = "D")(ll06) # Actinop unfiltered
#make a colour range on the filtered BLAST elements
pal07<-viridis_pal(option = "A")(ll07) # not Actinop filtered
pal08<-viridis_pal(option = "D")(ll08) # Actinop filtered
#see the colors in a pie
pie(rep(1,ll06), col=sample(pal06, ll06)) #based on unfiltered BLAST, , Actinop
pie(rep(1,ll08), col=sample(pal08, ll08)) #based on filtered BLAST, Actinop
#see colours in pie
pie(rep(1,ll05), col=sample(pal05, ll05)) #based on unfiltered BLAST not Actinop
pie(rep(1,ll07), col=sample(pal07, ll07)) #based on filtered BLAST not Actinop
# make data frames with colours matching family names
df_col_unfilt_not_tspc_fam01 <-as.data.frame(cbind(unique(df_ncm03_unfilt_not_tspc$blast_unfilt_fam),c(pal05)))
df_col_unfilt_tspc_fam01 <-as.data.frame(cbind(unique(df_ncm03_unfilt_tspc$blast_unfilt_fam),c(pal06)))
#bind the two dataframes together by row
df_col_unfilt_fam02<-rbind(df_col_unfilt_tspc_fam01,df_col_unfilt_not_tspc_fam01)


# make data frames with colours matching family names
df_col_filt_not_tspc_fam01 <-as.data.frame(cbind(unique(df_ncm03_filt_not_tspc$blast_filt_fam),c(pal07)))
df_col_filt_tspc_fam01 <-as.data.frame(cbind(unique(df_ncm03_filt_tspc$blast_filt_fam),c(pal08)))
#bind the two dataframes together by row
df_col_filt_fam02<-rbind(df_col_filt_tspc_fam01,df_col_filt_not_tspc_fam01)
#assign color to coloumn in df matching the columns the colors were based on
df_ncm02$col_filt_fam <- df_col_filt_fam02$V2[match(df_ncm02$blast_filt_fam, df_col_filt_fam02$V1)]
df_ncm02$col_unfilt_fam <- df_col_unfilt_fam02$V2[match(df_ncm02$blast_unfilt_fam, df_col_unfilt_fam02$V1)]
# make the hex color codes characters to allow them to eb interpreted as hex colors
df_ncm02$col_filt_fam <- as.character(df_ncm02$col_filt_fam)
df_ncm02$col_unfilt_fam <- as.character(df_ncm02$col_unfilt_fam)
# see them in a pie
c <- as.character(df_col_filt_fam02$V2)
l <- length(df_col_filt_fam02$V2)
pie(rep(1,l), col=sample(c, l))
# see them in a pie
c <- as.character(df_col_unfilt_fam02$V2)
l <- length(df_col_unfilt_fam02$V2)
pie(rep(1,l), col=sample(c, l))
#count genus-species in the unfiltered list
csg_unf1_df <- as.data.frame(table(df_ncm02$blast_unfilt_genus_species))
#count genus-species in the filtered list
csg_f1_df <- as.data.frame(table(df_ncm02$blast_filt_genus_species))


#___________________________________________________________________________________
# make a data frame for unfiltered colors
#___________________________________________________________________________________
# make a data frame with unique genus-species from the unfiltered BLAST hits
# to use for preparing a color range that can be matched back to the main data frame
# afterwards
colnames(df_ncm02)
#define the columns to keep
keeps <- c( "blast_unfilt_class_ord_fam_gen_spc",
            "blast_unfilt_fam",
            "blast_unfilt_genus",
            "blast_unfilt_genus_species",
            "col_unfilt_fam")
#keep only selected columns
df_col_unf_fam01 <- df_ncm02[keeps]
#remove rows that are duplicated for a column
df_col_unf_fam02<- df_col_unf_fam01[!duplicated(df_col_unf_fam01$blast_unfilt_genus_species), ]
#remove rows with NAs : https://stackoverflow.com/questions/4862178/remove-rows-with-all-or-some-nas-missing-values-in-data-frame
df_col_unf_fam03 <- df_col_unf_fam02[complete.cases(df_col_unf_fam02), ]
df_col_unf_fam03 <- df_col_unf_fam02

head(df_col_unf_fam03, 5)
#https://chartio.com/resources/tutorials/how-to-sort-a-data-frame-by-multiple-columns-in-r/
#reorder the data frame by class, then by fam then by genus and species
df_col_unf_fam04 <- df_col_unf_fam03[
  with(df_col_unf_fam03, order(blast_unfilt_class_ord_fam_gen_spc,
                               blast_unfilt_fam,
                               blast_unfilt_genus,
                               blast_unfilt_genus_species)),]
#https://stackoverflow.com/questions/30491497/running-count-within-groups-in-a-dataframe
#make count per class
library(dplyr)
tbl_col_unf_fam04 <-df_col_unf_fam04 %>%
  group_by(blast_unfilt_fam) %>%
  mutate(count = seq(n()))
#make the tibble a data frame instead
df_col_unf_fam05 <- as.data.frame(tbl_col_unf_fam04)
#get the max count per class
tbl_col_unf_fam05 <-df_col_unf_fam04 %>%
  group_by(blast_unfilt_fam) %>%
  mutate(max = max(n()))
#make the tibble a data frame instead
df_col_unf_fam06 <- as.data.frame(tbl_col_unf_fam05)
#match back to the counted data frame
df_col_unf_fam04$count <- df_col_unf_fam05$count[match(df_col_unf_fam05$blast_unfilt_genus_species,df_col_unf_fam04$blast_unfilt_genus_species)]
#match back to the max values data frame
df_col_unf_fam04$max <- df_col_unf_fam06$max[match(df_col_unf_fam06$blast_unfilt_fam,df_col_unf_fam04$blast_unfilt_fam)]
#get fractions for colors
df_col_unf_fam04$frq_col <- (df_col_unf_fam04$count/df_col_unf_fam04$max)
# copy the data frame
df_col_unf_fam07 <- df_col_unf_fam04

#make an empty list : https://stackoverflow.com/questions/55445629/appending-a-list-in-a-loop-r
lst_col <- list()
#iterate over elements and append to the empty list
for (i in df_col_unf_fam07$blast_unfilt_class_ord_fam_gen_spc){
  hc<-df_col_unf_fam07$col_unfilt_fam[match(i,df_col_unf_fam07$blast_unfilt_class_ord_fam_gen_spc)]
  f <- colorRamp(c("white", hc))
  zv<-df_col_unf_fam07$frq_col[match(i,df_col_unf_fam07$blast_unfilt_class_ord_fam_gen_spc)]
  hexcol03 <- (colors <- rgb(f(zv)/255))
  #listtmp = hexcol03[, lfg]
  lst_col<- append(lst_col, list(hexcol03))
}
#make the list a matrix, and turn them in to characters
hcol_cl3 <- as.character(as.matrix(lst_col))

length(unique(hcol_cl3))
length(df_col_unf_fam07$blast_unfilt_genus_species)
#append them back to the dataframe
df_col_unf_fam07$col_unfilt_gen_spc <- hcol_cl3
#use a different name for colors to test
colors<-df_col_unf_fam07$col_unfilt_gen_spc
## Check that it works
image(seq_along(df_col_unf_fam07$col_unfilt_gen_spc), 1, as.matrix(seq_along(df_col_unf_fam07$col_unfilt_gen_spc)), col=colors,
      axes=FALSE, xlab="", ylab="")
#___________________________________________________________________________________


#___________________________________________________________________________________
# make a data frame for filtered colors
#___________________________________________________________________________________

# make a data frame with unique genus-species from the filtered BLAST hits
# to use for preparing a color range that can be matched back to the main data frame
# afterwards
#define the columns to keep
keeps <- c("blast_filt_class_ord_fam_gen_spc" ,
           "blast_filt_fam",
           "blast_filt_genus",
           "blast_filt_genus_species",
           "col_filt_fam")
#keep only selected columns
df_col_f_fam01 <- df_ncm02[keeps]
#remove rows that are duplicated for a column
df_col_f_fam02<- df_col_f_fam01[!duplicated(df_col_f_fam01$blast_filt_genus_species), ]
#remove rows with NAs : https://stackoverflow.com/questions/4862178/remove-rows-with-all-or-some-nas-missing-values-in-data-frame
df_col_f_fam03 <- df_col_f_fam02[complete.cases(df_col_f_fam02), ]
df_col_f_fam02 <- df_col_f_fam03

head(df_col_f_fam03, 5)
#https://chartio.com/resources/tutorials/how-to-sort-a-data-frame-by-multiple-columns-in-r/
#reorder the data frame by class, then by fam then by genus and species
df_col_f_fam04 <- df_col_f_fam03[
  with(df_col_f_fam03, order(blast_filt_class_ord_fam_gen_spc,
                             blast_filt_fam,
                             blast_filt_genus,
                             blast_filt_genus_species)),]
#https://stackoverflow.com/questions/30491497/running-count-within-groups-in-a-dataframe
#make count per class
library(dplyr)
tbl_col_f_fam04 <-df_col_f_fam04 %>%
  group_by(blast_filt_fam) %>%
  mutate(count = seq(n()))
#make the tibble a data frame instead
df_col_f_fam05 <- as.data.frame(tbl_col_f_fam04)
#get the max count per class
tbl_col_f_fam05 <-df_col_f_fam04 %>%
  group_by(blast_filt_fam) %>%
  mutate(max = max(n()))
#make the tibble a data frame instead
df_col_f_fam06 <- as.data.frame(tbl_col_f_fam05)

#match back to the counted data frame
df_col_f_fam04$count <- df_col_f_fam05$count[match(df_col_f_fam05$blast_filt_genus_species,df_col_f_fam04$blast_filt_genus_species)]
#match back to the max values data frame
df_col_f_fam04$max <- df_col_f_fam06$max[match(df_col_f_fam06$blast_filt_fam,df_col_f_fam04$blast_filt_fam)]
#get fractions for colors
df_col_f_fam04$frq_col <- (df_col_f_fam04$count/df_col_f_fam04$max)
# copy the data frame
df_col_f_fam07 <- df_col_f_fam04

#make an empty list : https://stackoverflow.com/questions/55445629/appending-a-list-in-a-loop-r
lst_col <- list()
#iterate over elements and append to the empty list
for (i in df_col_f_fam07$blast_filt_class_ord_fam_gen_spc){
  hc<-df_col_f_fam07$col_filt_fam[match(i,df_col_f_fam07$blast_filt_class_ord_fam_gen_spc)]
  f <- colorRamp(c("white", hc))
  zv<-df_col_f_fam07$frq_col[match(i,df_col_f_fam07$blast_filt_class_ord_fam_gen_spc)]
  hexcol03 <- (colors <- rgb(f(zv)/255))
  #listtmp = hexcol03[, lfg]
  lst_col<- append(lst_col, list(hexcol03))
}
#make the list a matrix, and turn them in to characters
hcol_cl3 <- as.character(as.matrix(lst_col))
#append them back to the dataframe
df_col_f_fam07$col_filt_gen_spc <- hcol_cl3
#use a different name for colors to test
colors<-df_col_f_fam07$col_filt_gen_spc
## Check that it works
image(seq_along(df_col_f_fam07$col_filt_gen_spc), 1, as.matrix(seq_along(df_col_f_fam07$col_filt_gen_spc)), col=colors,
      axes=FALSE, xlab="", ylab="")
#___________________________________________________________________________________

#remove rows with NAs : https://stackoverflow.com/questions/4862178/remove-rows-with-all-or-some-nas-missing-values-in-data-frame
df_ncm03 <- df_ncm02[complete.cases(df_ncm02), ]

df_ncm03 <- df_ncm02
#match back new colours to the genus_species - filtered BLAST hits
df_ncm03$col_filt_gen_spc <- df_col_f_fam07$col_filt_gen_spc[match(df_ncm03$blast_filt_genus_species,df_col_f_fam07$blast_filt_genus_species)]
#match back new colours to the genus_species - unfiltered BLAST hits
df_ncm03$col_unfilt_gen_spc <- df_col_unf_fam07$col_unfilt_gen_spc[match(df_ncm03$blast_unfilt_genus_species,df_col_unf_fam07$blast_unfilt_genus_species)]

head(df_ncm02,4)
unique(df_ncm02$seq.rd.cnt)
unique(df_ncm02$smpl.loc)
unique(df_ncm02$blast_unfilt_genus_species)
#
## if color value is na, then replace with a grey hex color "#9e9e9e"
df_ncm03$col_filt_gen_spc[is.na(df_ncm03$col_filt_gen_spc)] <- "#9E9E9E"
df_ncm03$col_unfilt_gen_spc[is.na(df_ncm03$col_unfilt_gen_spc)] <- "#9E9E9E"
length(unique(df_ncm03$col_unfilt_gen_spc))
## if gen spc name is NA then replace : see: https://datascience.stackexchange.com/questions/14273/how-to-replace-na-values-with-another-value-in-factors-in-r
levels(df_ncm03$blast_unfilt_genus_species)<-c(levels(df_ncm03$blast_unfilt_genus_species),"None")  #Add the extra level to your factor
df_ncm03$blast_unfilt_genus_species[is.na(df_ncm03$blast_unfilt_genus_species)] <- "None"           #Change NA to "None"
length(unique(df_ncm03$blast_unfilt_genus_species))

#change read counts to numeric
df_ncm03$seq.rd.cnt <- as.numeric(df_ncm03$seq.rd.cnt)
#make a list of unique colors
lst_col3unfilt_genspc_unq <-unique(df_ncm03$col_unfilt_gen_spc)
unique(df_ncm03$blast_unfilt_genus_species)
#create data frame for total number of counts of each bar
total_read_count03 <- df_ncm03 %>% group_by(smpl.loc) %>% summarise(seq.rd.cnt = sum(seq.rd.cnt))


#df_ncm03

#___________________________________________________________________________________

# start the plots
#___________________________________________________________________________________

#create 100% stacked bar plot with seqN on the x-axis
Stacked_bar_plot3 <- ggplot() +
  geom_bar(data = df_ncm03, aes(x = smpl.loc, 
                                y = seq.rd.cnt, 
                                fill = blast_unfilt_class_ord_fam_gen_spc), 
           position="fill", stat="identity") + #, color="white") +
  #Get same result with
  #geom_col(position="fill") + #, color="white") +
  #
  labs(x = "unfilt_incl_none", y = "Proportion of reads/sample",
       fill = "Sequences") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  scale_fill_manual(values=c(as.character(lst_col3unfilt_genspc_unq))) +
  guides(fill=guide_legend(ncol=1)) +
  geom_text(data=total_read_count03, aes(x = smpl.loc, y = 1.05, 
                                         label = seq.rd.cnt), vjust=0, angle = 90)
print(Stacked_bar_plot3)

#subset data frame if observations does not match
df_ncm05 <- df_ncm03[ which(df_ncm03$blast_unfilt_class=="Actinopteri" 
                            | df_ncm03$blast_unfilt_class=="Mammalia"), ]
unique(df_ncm03$blast_unfilt_class)
unique(df_ncm05$blast_unfilt_class)
#get list of colors
lst_col5unfilt_genspc_unq <-unique(df_ncm05$col_unfilt_gen_spc)
#create data frame for total number of counts of each bar
total_read_count05 <- df_ncm05 %>% group_by(smpl.loc) %>% summarise(seq.rd.cnt = sum(seq.rd.cnt))
#create 100% stacked bar plot with seqN on the x-axis
Stacked_bar_plot6 <- ggplot() +
  geom_bar(data = df_ncm05, aes(x = smpl.loc, 
                                y = seq.rd.cnt, 
                                fill = blast_unfilt_class_ord_fam_gen_spc), 
           position="fill", stat="identity") + #, color="white") +
  #Get same result with
  #geom_col(position="fill") + #, color="white") +
  labs(x = "unfilt_only_target_spc", y = "Proportion of reads/sample",
       fill = "Sequences") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  scale_fill_manual(values=c(as.character(lst_col5unfilt_genspc_unq))) +
  guides(fill=guide_legend(ncol=1)) +
  geom_text(data=total_read_count05, aes(x = smpl.loc, y = 1.05, 
                                         label = seq.rd.cnt), vjust=0, angle = 90)
print(Stacked_bar_plot6)


lst_col3filt_genspc_unq <-unique(df_ncm03$col_filt_gen_spc)
#create data frame for total number of counts of each bar
total_read_count03 <- df_ncm03 %>% group_by(smpl.loc) %>% summarise(seq.rd.cnt = sum(seq.rd.cnt))
#create 100% stacked bar plot with seqN on the x-axis
Stacked_bar_plot4 <- ggplot() +
  geom_bar(data = df_ncm03, aes(x = smpl.loc, y = seq.rd.cnt, 
                                fill = blast_filt_class_ord_fam_gen_spc), 
           position="fill", stat="identity") + #, color="white") +
  #Get same result with
  #geom_col(position="fill") + #, color="white") +
  #
  labs(x = "filt_incl_none", y = "Proportion of reads/sample",
       fill = "Sequences") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  scale_fill_manual(values=c(as.character(lst_col3filt_genspc_unq))) +
  guides(fill=guide_legend(ncol=1)) +
  geom_text(data=total_read_count03, aes(x = smpl.loc, y = 1.03,
                                         label = seq.rd.cnt), vjust=0, angle = 90)
print(Stacked_bar_plot4)

#subset data frame if observations does not match
df_ncm04 <- df_ncm03[ which(!df_ncm03$blast_filt_class=="none"), ]
#get list of colors
lst_col4filt_genspc_unq <-unique(df_ncm04$col_filt_gen_spc)
#create data frame for total number of counts of each bar
total_read_count04 <- df_ncm04 %>% group_by(smpl.loc) %>% summarise(seq.rd.cnt = sum(seq.rd.cnt))
#create 100% stacked bar plot with seqN on the x-axis
Stacked_bar_plot5 <- ggplot() +
  geom_bar(data = df_ncm04, aes(x = smpl.loc, y = seq.rd.cnt, 
                                fill = blast_filt_class_ord_fam_gen_spc), 
           position="fill", stat="identity") + #, color="white") +
  #Get same result with
  #geom_col(position="fill") + #, color="white") +
  #
  labs(x = "filt_excl_none", y = "Proportion of reads/sample",
       fill = "Sequences") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  scale_fill_manual(values=c(as.character(lst_col4filt_genspc_unq))) +
  guides(fill=guide_legend(ncol=1)) +
  geom_text(data=total_read_count04, aes(x = smpl.loc, y = 1.05, 
                                         label = seq.rd.cnt), vjust=0, angle = 90)
print(Stacked_bar_plot5)



#jeg har prøvet at tilføje værdier skrevet direkte på søjlerne, men når jeg gør det forsvinder søjlerne og kun værdier er tilbage
###Figure1 <- Figure + geom_text(aes(label=seq.rd.cnt),stat="identity",position=position_dodge(0.5))

##gather bar plots in one figure
figure <- ggarrange(Stacked_bar_plot3,
                    Stacked_bar_plot4,
                    Stacked_bar_plot5,
                    Stacked_bar_plot6,
                    labels = c("A", "B", "C", "D"),
                    ncol = 1, nrow = 4)

##print results
#print(Stacked_bar_plot)
#print(Stacked_bar_plot2)
#print(figure)

# # make a sequence of capital letters
# subfiglt <- LETTERS[seq( from = 1, to = 4 )]
# ##gather 5 bar plots in one figure
# figure <- ggpubr::ggarrange(Stacked_bar_plot_per_seq,
#                             Stacked_bar_plot_per_seq,
#                             Stacked_bar_plot_per_seq,
#                             Stacked_bar_plot_per_seq,
#                             labels = c(subfiglt),
#                             ncol = 2, nrow = 2)
# figure <- Stacked_bar_plot_per_seq
getwd()
#substitute on the input file name
filn01 <- gsub("part05_output_","",inp_fn2)
filn02 <- gsub("01.txt","",filn01)

filn02 <-"stackedbar_plot"
#paste together a new filename
plot.nm3 <- paste("part07_",libnm,"_",filn02,"02", sep="")
#plot.nm3 <- paste("part06_output_plot_on_",filn02,"02", sep="")
#print the plot in a pdf - open a pdf file
pdf(c(paste(plot.nm3,".pdf",  sep = ""))
    #set size of plot
    ,width=(1*8.2677),height=(4*3*2.9232))
#add the plot to the pdf
print(figure)
#close the pdf file again
dev.off()

#___________________________________________________________________________________

# end the plots
#___________________________________________________________________________________




#____________________________________________________________________________________
# make a csv-table for the blast hits - start
#____________________________________________________________________________________

#head(df_ncm04,10)
df_ncm04$seq.rd.cnt
keeps <- c(
  "blast_unfilt_genus_species",
  "seq.rd.cnt"
)
df_ncm06 <- df_ncm03[keeps] #species names assigned unfiltered including all
# count up the total count of sequence reads per species : https://stackoverflow.com/questions/57328395/how-to-perform-sum-and-count-on-dataframe-in-r
df_ncm07 <- aggregate(cbind(seq.rd.cnt) ~ blast_unfilt_genus_species, 
          transform(df_ncm06, Count = 1), sum)
#keep only selected columns
df_spa_ufall_01 <- df_ncm03[keeps] #species names assigned unfiltered including all
#check the column names
#colnames(df_ncm04)
#define the columns to keep 
keeps <- c(
            "blast_unfilt_fam",
            "blast_unfilt_genus_species",
            "blast_filt_fam",
            "blast_filt_genus_species"
            )
#keep only selected columns
df_spa_ufall_01 <- df_ncm03[keeps] #species names assigned unfiltered including all
df_spa_fexno_01 <- df_ncm04[keeps] #species names assigned filtered excluding 'none'
df_spa_unfoa_01 <- df_ncm05[keeps] #species names assigned unfiltered only Actinopterygii

# Only retain unique rows: 
# https://stats.stackexchange.com/questions/6759/removing-duplicated-rows-data-frame-in-r
df_spa_ufall_02 <- df_spa_ufall_01[!duplicated(df_spa_ufall_01), ]
df_spa_fexno_02 <- df_spa_fexno_01[!duplicated(df_spa_fexno_01), ]
df_spa_unfoa_02 <- df_spa_unfoa_01[!duplicated(df_spa_unfoa_01), ]

# define a function: https://stackoverflow.com/questions/15162197/combine-rbind-data-frames-and-create-column-with-name-of-original-data-frames
AppenDFsourc <- function(dfNames) {
  do.call(rbind, lapply(dfNames, function(x) {
    cbind(get(x), source = x)
  }))
}
# use the function to bind rows in data frames keeping the source of the data frames
df_spa_03 <- AppenDFsourc(c("df_spa_ufall_02",
               "df_spa_fexno_02",
               "df_spa_unfoa_02"))
#replace in the column for the source
df_spa_03$source <- gsub('df_spa_ufall_02', 'unfilt_all', df_spa_03$source)
df_spa_03$source <- gsub('df_spa_fexno_02', 'filt_excl_none', df_spa_03$source)
df_spa_03$source <- gsub('df_spa_unfoa_02', 'unfilt_only_Actinopterygi', df_spa_03$source)
#unique(df_spa_03$source)
# read in table with comments from PRM
#df_PRM_comm <- read.table("part07_comments_PRM_per_species01.csv",sep=",", header = T)
# set 'fill=T' to TRUE to make sure that tables with irregular number of columns are read in as well
df_PRM_comm <- read.table("liste_over_SWK_blasthits_m_JMS_data_2020mar09_02.txt",sep=",", header = T, fill=T)
colnames(df_PRM_comm)
#replace underscores with spaces
df_PRM_comm$species_after_filtration <- gsub("_"," ",df_PRM_comm$blast_filt_genus_species)
#match notes and comments back
df_spa_03$PRM_note <- df_PRM_comm$PRM_note[match(df_spa_03$blast_unfilt_genus_species,df_PRM_comm$blast_unfilt_genus_species)]
df_spa_03$SWK_spm1 <- df_PRM_comm$SWK_spm1[match(df_spa_03$blast_unfilt_genus_species,df_PRM_comm$blast_unfilt_genus_species)]
df_spa_03$Oceanic_region <- df_PRM_comm$Oceanic_region[match(df_spa_03$blast_unfilt_genus_species,df_PRM_comm$blast_unfilt_genus_species)]
df_spa_03$PRM_kommentar1<- df_PRM_comm$PRM_kommentar1[match(df_spa_03$blast_unfilt_genus_species,df_PRM_comm$blast_unfilt_genus_species)]
df_spa_03$ngs_metabarcode_libr_nm <- libnm
df_spa_03$seq.rd.cnt <- df_ncm07$seq.rd.cnt[match(df_spa_03$blast_unfilt_genus_species,df_ncm07$blast_unfilt_genus_species)]
# define working directory
#my_wd <- "/home/hal9000/metabarcode_example/JMS_FL/1-demultiplexed"
# #set working directory
#setwd(my_wd)
csv_fnm <- paste("part07_",libnm,"_otus_blast.csv",sep="")
# write the data frame to a csv file
write.csv(df_spa_03,
          csv_fnm,
          row.names = FALSE)
#____________________________________________________________________________________
# make a csv-table for the blast hits - end
#____________________________________________________________________________________

#


#######
